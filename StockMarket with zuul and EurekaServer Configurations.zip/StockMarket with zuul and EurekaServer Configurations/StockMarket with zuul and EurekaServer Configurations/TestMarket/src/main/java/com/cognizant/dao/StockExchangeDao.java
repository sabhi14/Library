/**
 * 
 */
package com.cognizant.dao;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.entity.StockExchange;

/**
 * @author Admin
 *
 */
public interface StockExchangeDao extends CrudRepository<StockExchange, Serializable> {

}
