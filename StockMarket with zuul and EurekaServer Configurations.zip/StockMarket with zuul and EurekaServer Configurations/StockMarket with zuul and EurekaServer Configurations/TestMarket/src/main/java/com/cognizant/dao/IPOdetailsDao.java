package com.cognizant.dao;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.entity.IPODetails;

public interface IPOdetailsDao extends CrudRepository<IPODetails, Serializable>{

}
