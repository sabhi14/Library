/**
 * 
 */
package com.cognizant.service;

import org.springframework.stereotype.Service;
import com.cognizant.entity.StockExchange;
import com.cognizant.entity.Company;
import com.cognizant.entity.IPODetails;

/**
 * @author Admin
 *
 */

@Service
public interface AdminServices {
	Company save(Company company);

	void deleteByCompanyId(long companyId);

	Company findByCompanyName(String companyName);

	StockExchange save(StockExchange exchange);

	IPODetails save(IPODetails ipoDetails);

}
