/**
 * 
 */
package com.cognizant.controller;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.entity.Company;
import com.cognizant.entity.Users;
import com.cognizant.service.UserServices;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * @author Admin
 *
 */
@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	UserServices services;

// user register
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public Users registerUser(@RequestBody Users users) throws ServletException {
		Users users1 = services.save(users);
		
			Properties propvls = new Properties();

			final String sendrmailid = "stockmarketcharting@gmail.com";
			final String pwd = "raes17081996";

			String smtphost = "smtp.gmail.com";

			propvls.put("mail.smtp.auth", "true");
			propvls.put("mail.smtp.starttls.enable", "true");
			propvls.put("mail.smtp.host", smtphost);
			propvls.put("mail.smtp.port", "587");

			Session sessionobj = Session.getInstance(propvls, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					System.out.println("In session");
					return new PasswordAuthentication(sendrmailid, pwd);
				}
			});

			try {
				// Create MimeMessage object & set values
				Message messageobj = new MimeMessage(sessionobj);
				messageobj.setFrom(new InternetAddress(sendrmailid));
				messageobj.setRecipients(Message.RecipientType.TO, InternetAddress.parse(users1.getEmail()));
				messageobj.setSubject("Congrats on registration to StockMarket Happy Trading!");
				messageobj.setText("You are successfully registered to the StockMarket with the following details"
						+ "\n userId: " + users1.getUserId() + "\n userName: " + users1.getUserName() + "\n Password: "
						+ users1.getPassword() + "Click here to login http://localhost:8086/users/login"
						+ "\n Happy Trading...");
				// Now send the message
				Transport.send(messageobj);
				System.out.println("Your email sent successfully....");
			} catch (MessagingException exp) {
				throw new RuntimeException(exp);
			}
			return users1;
		}
	

// user update
	@Transactional
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public Users updateUser(@RequestBody Users users) {

		return services.save(users);

	}

//user login m
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestBody Users login) throws ServletException {
		System.out.println("Inside Log in");

		String jwtToken = "";

		if (login.getUserName() == null || login.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String userName = login.getUserName();
		String password = login.getPassword();

		Users user = services.findUser(userName, password);
		String pwd = user.getPassword();

		if (!password.equals(pwd)) {
			throw new ServletException("Invalid login. Please check your name and password.");
		} else if (user.getIsBlocked() == true) {
			throw new ServletException("Admin has blocked you.Please contact admin for more updates");
		} else {
			jwtToken = Jwts.builder().setSubject(userName).claim("roles", "user")
					.signWith(SignatureAlgorithm.HS256, "secretkey").compact();

			return jwtToken;
		}
	}

	// search a company
	@RequestMapping(value = "/Search/Company", method = RequestMethod.POST)
	public Company findCompany(@RequestBody Company company) throws ServletException {
		Company company1 = new Company();
		String companyName = company.getCompanyName();
		company1 = services.findByCompanyName(companyName);
		if(company1==null)
		{
			throw new ServletException("Company not found.Try with some other keywords");
		}
		else
		{
			return company1;
		}
		

	}

}
