package com.cognizant.service;

import com.cognizant.entity.Company;
import com.cognizant.entity.Users;

public interface UserServices
{
	Users save(Users users);
	Users findUser(String userName, String password);
	void deleteByUserId(long userId);
	Company findByCompanyName(String companyName);
	Users findByUserId(long userId);
}
