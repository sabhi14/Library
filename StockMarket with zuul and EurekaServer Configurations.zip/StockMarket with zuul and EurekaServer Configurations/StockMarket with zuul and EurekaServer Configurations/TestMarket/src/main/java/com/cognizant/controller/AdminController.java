/**
 * 
 */
package com.cognizant.controller;

import javax.servlet.ServletException;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.entity.Company;
import com.cognizant.entity.IPODetails;
import com.cognizant.entity.StockExchange;
import com.cognizant.entity.Users;
import com.cognizant.service.AdminServices;
import com.cognizant.service.UserServices;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * @author Admin
 *
 */
@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/Admin/Authorities")
public class AdminController {
	@Autowired
	AdminServices adminServices;
	@Autowired
	UserServices userServices;
	// Admin Log in Authorization

	@RequestMapping(value = "/Authorization", method = RequestMethod.POST)
	public String login(@RequestBody Users login) throws ServletException {

		String jwtToken = "";

		if (login.getUserName() == null || login.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String userName = login.getUserName();
		String password = login.getPassword();

		Users user = userServices.findUser(userName, password);

		String uType = user.getUserType();

		if (uType.equalsIgnoreCase("Admin")) {
			jwtToken = Jwts.builder().setSubject(userName).claim("roles", "user")
					.signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		} else {
			throw new ServletException("Not an Admin");
		}
		return jwtToken;
	}

	// Add a company
	@RequestMapping(value = "/Add/Company", method = RequestMethod.POST)
	public Company addCompany(@RequestBody Company company) throws ServletException {
		Company company1 = new Company();
		company1 = adminServices.save(company);
		return company1;

	}
	// update a company details

	@RequestMapping(value = "/Update/Company/Details", method = RequestMethod.POST)
	public Company updateCompany(@RequestBody Company company) {
		return adminServices.save(company);

	}

	// update a IPO details
	@RequestMapping(value = "/Update/Ipo/Details", method = RequestMethod.POST)
	public IPODetails updateIPODetails(@RequestBody IPODetails ipoDetails) throws ServletException {
		IPODetails details = new IPODetails();
		details = adminServices.save(ipoDetails);
		return details;

	}

	// delete a company
	@RequestMapping(value = "/Edit/Company/Database/Delete", method = RequestMethod.POST)
	public String deleteCompany(@RequestParam long companyId) {
		adminServices.deleteByCompanyId(companyId);
		return "Company Deleted";

	}
	// delete a user

	@RequestMapping(value = "/Edit/User/Database/Delete", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String deleteUser(@RequestParam long userId) {
		userServices.deleteByUserId(userId);
		return "User Deleted";

	}

//add stockexchange details
	@RequestMapping(value = "/add/StockExchange/Details", method = RequestMethod.POST)
	public StockExchange saveStockExchange(@RequestBody StockExchange exchange) {
		return adminServices.save(exchange);

	}

// add stock details
	@RequestMapping(value = "/Update/StockExchange/Details", method = RequestMethod.POST)
	public StockExchange updateStockExchange(@RequestBody StockExchange exchange) {
		return adminServices.save(exchange);

	}

// search a company
	@RequestMapping(value = "/Search/Company", method = RequestMethod.POST)
	public Company findCompany(@RequestBody Company company) {
		String companyName = company.getCompanyName();
		return adminServices.findByCompanyName(companyName);
	}

//search a User By id
	@RequestMapping(value = "/Search/Users", method = RequestMethod.POST)
	public Users findUser(@RequestBody Users users) {
		long userId = users.getUserId();
		return userServices.findByUserId(userId);

	}

// Block an User
	@RequestMapping(value = "/block/user/", method = RequestMethod.POST)
	@Transactional
	public String blockUser(@RequestParam long userId) {
		Users users = new Users();
		users = userServices.findByUserId(userId);
		if (users.getIsBlocked() == true) {
			return "User is already blocked";
		} else {
			users.setIsBlocked(true);
			return "User is now Blocked";
		}

	}

// Unblock an User
	@RequestMapping(value = "/unblock/user/", method = RequestMethod.POST)
	@Transactional
	public String unblockUser(@RequestParam long userId) {
		Users users = new Users();
		users = userServices.findByUserId(userId);
		if (users.getIsBlocked() == true) {
			users.setIsBlocked(false);
			return "User is now unblocked";

		} else {
			return "User is not Blocked";
		}
	}

// block a company
	@RequestMapping(value = "/block/company/", method = RequestMethod.POST)
	@Transactional
	public String blockCompany(@RequestParam String companyName) {
		Company company = new Company();
		company = adminServices.findByCompanyName(companyName);
		if (company.getIsCompanyBlocked() == true) {
			return "Company is already blocked";
		} else {
			company.setIsCompanyBlocked(true);
			return "Company is now blocked";
		}

	}

// unblock a company
	@RequestMapping(value = "/unblock/company/", method = RequestMethod.POST)
	@Transactional
	public String unblockCompany(@RequestParam String companyName) {
		Company company = new Company();
		company = adminServices.findByCompanyName(companyName);
		if (company.getIsCompanyBlocked() == true) {
			company.setIsCompanyBlocked(false);
			return "Company is now unblocked";
		} else {

			return "Company is not blocked";
		}

	}

}
