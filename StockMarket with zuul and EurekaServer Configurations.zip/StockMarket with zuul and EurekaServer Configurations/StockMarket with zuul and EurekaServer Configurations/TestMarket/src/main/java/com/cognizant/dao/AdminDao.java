package com.cognizant.dao;

import java.io.Serializable;
import org.springframework.data.repository.CrudRepository;
import com.cognizant.entity.Users;

public interface AdminDao extends CrudRepository<Users,Serializable> {
	
	
}