/**
 * 
 */
package com.cognizant.dao;
import java.io.Serializable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.entity.Users;

/**
 * @author Admin
 *
 */
@Repository
public interface UserDao extends CrudRepository<Users, Serializable>
{
	 void deleteByUserId(long userId);
	 Users findDistinctByUserNameAndPassword(String userName, String password);
	 Users findByUserId(long userId);


}
