/**
 * 
 */
package com.cognizant.dao;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.entity.Company;

/**
 * @author Admin
 *
 */
public interface CompanyDao extends CrudRepository<Company, Serializable>{
	void deleteByCompanyId(long companyId);
	Company findByCompanyName(String companyName);

}
