/**
 * 
 */
package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.dao.CompanyDao;
import com.cognizant.dao.IPOdetailsDao;
import com.cognizant.dao.StockExchangeDao;
import com.cognizant.entity.Company;
import com.cognizant.entity.IPODetails;
import com.cognizant.entity.StockExchange;


/**
 * @author Admin
 *
 */
@Service
public class AdminServicesImpl implements AdminServices {
	@Autowired
	private StockExchangeDao exchangeDao;
	@Autowired 
	private IPOdetailsDao ipodetailsDao;
	@Autowired
	private CompanyDao companyDao;
	@Override
	public Company save(Company company) {

		return companyDao.save(company);
	}

	@Override
	public void deleteByCompanyId(long companyId) {
		companyDao.deleteById(companyId);

	}

	@Override
	public StockExchange save(StockExchange exchange) {
		return exchangeDao.save(exchange);
	}

	@Override
	public Company findByCompanyName(String companyName) {
		return companyDao.findByCompanyName(companyName);
	}

	@Override
	public IPODetails save(IPODetails ipoDetails) {
		return ipodetailsDao.save(ipoDetails);
	}
	


}
