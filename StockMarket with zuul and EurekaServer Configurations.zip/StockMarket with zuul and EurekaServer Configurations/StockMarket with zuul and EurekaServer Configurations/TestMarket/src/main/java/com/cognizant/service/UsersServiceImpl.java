/**
 * 
 */
package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.dao.CompanyDao;
import com.cognizant.dao.UserDao;
import com.cognizant.entity.Company;
import com.cognizant.entity.Users;

/**
 * @author Admin
 *
 */
@Service
public  class UsersServiceImpl implements UserServices {
	@Autowired
	AdminDao admindao;
	@Autowired
	UserDao userdao;
	@Autowired
	CompanyDao companyDao;

	@Override
	public Users save(Users users) {
		return userdao.save(users);
	}

	@Override
	public Users findUser(String userName, String password) {

		return userdao.findDistinctByUserNameAndPassword(userName, password);
	}

	@Override
	public void deleteByUserId(long userId) {
		userdao.deleteById(userId);

	}

	@Override
	public Company findByCompanyName(String companyName) {
		return companyDao.findByCompanyName(companyName);
	}

	@Override
	public Users findByUserId(long userId) {
		return userdao.findByUserId(userId);
	}
	
	
    
	
}
