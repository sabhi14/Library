/**
 * 
 */
package com.cognizant.stockmarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cognizant.stockmarket.entity.IPODetails;
import com.cognizant.stockmarket.service.IPOService;

@RestController
@RequestMapping("/ipo")
public class IPOController {

	@Autowired
	private IPOService ipoService;

	@PostMapping()
	public void addIPO(@RequestBody IPODetails ipo) {
		try {
			ipoService.addIPO(ipo);
		} catch (Exception ex) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid IPO details");
		}
	}

	@GetMapping()
	public List<IPODetails> getIPO() {
		try {
			return ipoService.getIPO();
		} catch (Exception ex) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid IPO details");
		}
	}

}
