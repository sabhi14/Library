package com.cognizant.stockmarket.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.stockmarket.entity.Company;
import com.cognizant.stockmarket.entity.Sectors;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> {

	@Modifying
	@Transactional
	@Query(value = "UPDATE company SET boardof_directors =?, brief_write_up=?, ceo_name=?, company_name=?, is_company_blocked=?, listed_in_stock_exchanges=?, stock_code=?, turnover=?, sector_id=? WHERE company_id=?", nativeQuery = true)
	Integer updateCompany(String bod, String bwf, String ceo, String cn, boolean isb, boolean lise, String sc, long to,
			long sectorId, long compId);

}
