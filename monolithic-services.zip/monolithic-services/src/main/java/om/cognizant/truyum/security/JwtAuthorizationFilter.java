package om.cognizant.truyum.security;

public class JwtAuthorizationFilter {

}
