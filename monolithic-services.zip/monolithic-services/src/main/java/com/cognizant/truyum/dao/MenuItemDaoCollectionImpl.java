package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private static List<MenuItem> menuItemList = null;

	public MenuItemDaoCollectionImpl() {
		if (menuItemList == null) {
			menuItemList = new ArrayList<>();
			ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
			menuItemList = context.getBean("menuItemList",ArrayList.class);
		}
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		List<MenuItem> menuItemListCustomer = new ArrayList<>();
		for (MenuItem menuItem : menuItemList) {
			if (menuItem.isActive() == true
					&& menuItem.getDateOfLaunch().compareTo(new Date()) <= 0) {
				menuItemListCustomer.add(menuItem);
			}
		}
		return menuItemListCustomer;
	}

	@Override
	public MenuItem modifyMenuItem(MenuItem menuItem) {
		menuItemList.set((int) menuItem.getId() - 1, menuItem);
		return menuItemList.get((int)menuItem.getId()-1);
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		MenuItem item = menuItemList.get((int) menuItemId -1);
		return item;
	}

}
