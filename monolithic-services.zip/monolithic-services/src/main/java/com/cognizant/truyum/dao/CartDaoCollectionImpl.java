package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

@Component
public class CartDaoCollectionImpl implements CartDao {
	private static HashMap<Long, Cart> userCarts;
	private MenuItemDao menuItemDao;

	public CartDaoCollectionImpl() {
		if (userCarts == null) {
			userCarts = new HashMap<>();
		}
		menuItemDao = new MenuItemDaoCollectionImpl();
	}

	@Override
	public void addCartItem(long userId, long menuItemId) {
		if (userCarts.containsKey(userId)) {
			Cart cart = userCarts.get(userId);
			List<MenuItem> cartItems = cart.getMenuItemList();
			MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);

			double total = cart.getTotal();
			total += menuItem.getPrice();

			cartItems.add(menuItem);
			cart = new Cart(cartItems, total);
			userCarts.put(userId, cart);

		} else {
			List<MenuItem> cartItems = new ArrayList<>();
			MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
			cartItems.add(menuItem);
			Cart cart = new Cart(cartItems, menuItem.getPrice());
			userCarts.put(userId, cart);
		}
	}

	@Override
	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
		if(userCarts.get(userId)==null)
		{
			throw new CartEmptyException("Cart is Empty");
		}
		else
		{
			List<MenuItem> menuItemList = userCarts.get(userId).getMenuItemList();
			if (menuItemList.isEmpty()) {
				throw new CartEmptyException();
			}
			return menuItemList;
		}
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {

		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		userCarts.get(userId).getMenuItemList().remove(menuItem);

	}

}
