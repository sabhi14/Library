package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemService {

	@Autowired
	private MenuItemDaoCollectionImpl menuItemDao;
	
	public MenuItemService() {
		
	}
	
	public List<MenuItem> getMenuItemListCustomer(){
		return menuItemDao.getMenuItemListCustomer();
	}
	
	public MenuItem getMenuItem(long menuItemId) {
		return menuItemDao.getMenuItem(menuItemId);
	}
	
	public MenuItem modifyMenuItem(MenuItem menuItem) {
		return menuItemDao.modifyMenuItem(menuItem);
	}
}
